import React from 'react';
import ReactDOM from 'react-dom';

//using the react-dom render method, we access our html and
//attach our react app at this connection point
ReactDOM.render(<YourElementHere/>, document.getElementById('app'));
